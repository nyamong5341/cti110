print("Enter the first number\n")
x = int(input())
print("Enter the second number\n")
y = int(input())

#adding the two numbers
z = x + y

#multiplying the two numbers
v = x * y

print(x, end = '\n')
print(y, end = '\n')
print(z, end = '\n')
print(v, end = '\n')


